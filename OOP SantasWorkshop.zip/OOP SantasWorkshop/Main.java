
public class Main {

	public static void main(String[] args) {

		Gift book = new Gift("Harry Potter and the Philosopher's Stone", 2);
		// Gift car = new Gift("Red monster truck", 7);
		Package gifts = new Package();
		gifts.addGift(book);
//		gifts.addGift(car);
//		System.out.println(gifts.totalWeight());
//
//		System.out.println("Gift's name" + book.getName());
//		System.out.println("Gift's weight: " + book.getWeight());
//
//		System.out.println("Gift: " + book);
//		System.out.println(car);
	}
}
