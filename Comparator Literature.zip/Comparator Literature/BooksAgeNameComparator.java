import java.util.Comparator;

class BooksAgeNameComparator implements Comparator<Book> {

	@Override
	public int compare(Book b1, Book b2) {
		if (b1.getAgeRecommended() - b2.getAgeRecommended() == 0) {
			return b1.getName().compareTo(b2.getName());
		} else {
			return b1.getAgeRecommended() - b2.getAgeRecommended();
		}
	}

}
