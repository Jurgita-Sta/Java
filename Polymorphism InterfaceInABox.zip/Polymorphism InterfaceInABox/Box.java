import java.util.ArrayList;

public class Box implements Packable {

	private ArrayList<Packable> items;
	private double capacity;

	public Box(int capacity) {
		this.capacity = capacity;
		this.items = new ArrayList<>();
	}

	public Box(double capacity) {
		this.capacity = capacity;
		this.items = new ArrayList<>();
	}

	public void add(Packable item) {
		if (capacity >= item.weight() + this.weight()) {
			items.add(item);
		}
	}

	@Override
	public String toString() {
		return "Box: " + items.size() + " items, total weight " + weight() + " kg";
	}

	@Override
	public double weight() {
		double weight = 0;
		for (Packable itemInBox : this.items) {
			weight = weight + itemInBox.weight();
		}
		return weight;
	}

}
