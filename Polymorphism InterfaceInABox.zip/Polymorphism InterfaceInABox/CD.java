public class CD implements Packable {

	String artist;
	String cdName;
	int publicationyear;

	public CD(String artist, String cdName, int publicationYear) {
		this.artist = artist;
		this.cdName = cdName;
		this.publicationyear = publicationYear;
	}

	@Override
	public double weight() {
		return 0.1;
	}

	@Override
	public String toString() {
		return artist + ": " + cdName + " (" + publicationyear + ")";
	}

}
