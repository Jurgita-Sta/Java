import java.util.ArrayList;

public class Hold {

	private ArrayList<Suitcase> suitcases;
	private int maximumWeight;

	public Hold(int maximumWeight) {
		this.suitcases = new ArrayList<>();
		this.maximumWeight = maximumWeight;
	}

	public void addSuitcase(Suitcase suitcase) {
		int holdWeight = 0;
		for (int i = 0; i < suitcases.size(); i++) {
			holdWeight += suitcases.get(i).totalWeight();
		}
		if ((this.maximumWeight - holdWeight) >= suitcase.totalWeight()) {
			this.suitcases.add(suitcase);
		}
	}

	@Override
	public String toString() {
		int holdWeight = 0;
		for (int i = 0; i < suitcases.size(); i++) {
			holdWeight += suitcases.get(i).totalWeight();
		}
		return this.suitcases.size() + " suitcases (" + holdWeight + " kg)";
	}

	public void printItems() {
		for (int i = 0; i < suitcases.size(); i++) {
			suitcases.get(i).printItems();
		}
	}

}
